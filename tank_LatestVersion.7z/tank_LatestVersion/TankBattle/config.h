#ifndef CONFIG_H
#define CONFIG_H

enum Direct{null, dup, ddown, dleft, dright};
#define Boarder 30
#define BasicSize 20
#define BaseSize 60

#endif // CONFIG_H
