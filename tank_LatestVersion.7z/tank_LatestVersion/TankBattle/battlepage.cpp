#include "battlepage.h"
#include "ui_battlepage.h"
#include "battlefield.h"
#include "tank.h"
#include "config.h"
#include <QPainter>
#include <QPixmap>
#include <QTimer>
#include <QDebug>
#include <QSound>

static int enemyDestroyed = 0;

BattlePage::BattlePage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BattlePage)
{
    ui->setupUi(this);
    this->setFixedSize(620, 600);
    this->move(550, 200);
    this->setWindowTitle("坦克大战");

    initial();//初始化

    connect(timer, &QTimer::timeout, this, &BattlePage::slot1);//连接计时器的信号到槽函数
    //connect(timer, &QTimer::timeout, this, &BattlePage::enemyMove);

}

BattlePage::~BattlePage()
{
    delete ui;

}

void BattlePage::initial()
{
    battle.map1();//加载地图

    //启动计时器
    timer = new QTimer(this);
    timer->start(50);

    //创建玩家
    player = new Tank(0);
    player->dir = dup;
    player->rect.setRect(11*BasicSize, 28*BasicSize, 40, 40);
    //Player的坐标
    player->x = player->rect.x();
    player->y = player->rect.y();
    //子弹位置、大小初始化
    player->bullet.rect.setRect(player->rect.x()+15, player->rect.y()+15, 10, 10);

    //创建敌人
    enemy1 = new Tank(1);  
    enemy2 = new Tank(1);
    enemy3 = new Tank(1);
//    enemy4 = new Tank(1);
//    enemy5 = new Tank(1);

    enemy1->bulletNum = true;
    enemy2->bulletNum = true;
    enemy3->bulletNum = true;
//    enemy4->bulletNum = true;
//    enemy5->bulletNum = true;

    enemy1->x = 2*BasicSize;
    enemy1->y = 1*BasicSize;
    enemy2->x = 6*BasicSize;
    enemy2->y = 1*BasicSize;
    enemy3->x = 12*BasicSize;
    enemy3->y = 1*BasicSize;
//    enemy4->x = 18*BasicSize;
//    enemy4->y = 1*BasicSize;
//    enemy5->x = 22*BasicSize;
//    enemy5->y = 1*BasicSize;

    enemy1->rect.setRect(2*BasicSize, 1*BasicSize, 40, 40);
    enemy2->rect.setRect(6*BasicSize, 1*BasicSize, 40, 40);
    enemy3->rect.setRect(12*BasicSize, 1*BasicSize, 40, 40);
//    enemy4->rect.setRect(18*BasicSize, 1*BasicSize, 40, 40);
//    enemy5->rect.setRect(22*BasicSize, 1*BasicSize, 40, 40);

    //update();
}

void BattlePage::slot1()
{
    tankMove(player);
    tankMove(enemy1);
    tankMove(enemy2);
    tankMove(enemy3);
//    tankMove(enemy4);
//    tankMove(enemy5);
}

void BattlePage::slot2()
{
    emit escape();

}

bool BattlePage::isBoom(Tank &tank)
{
    for(int i=0;i<31;i++){
        for(int j=0;j<30;j++){
            if(battle.battleField[i][j] != 0){
                if(tank.bullet.rect.intersects(battle.rect[i][j])){
                    //子弹消失并初始化
                    tank.bullet.isMove = false;
                    tank.bullet.rect.setRect(tank.rect.x()+15, tank.rect.y()+15, 10, 10);
                    tank.bulletNum = true;
                    //墙体消失
                    battle.battleField[i][j] = 0;
                    battle.rect[i][j].setRect(0, 0, 0, 0);

                    if(i == 14 && j == 27){
                        win.setText("你输了！");
                        win.show();
                        QSound::play(":/music/res/sound/fail.wav");
                        this->close();
                    }

                    return true;
                }
            }
        }
    }

    if(tank.bullet.rect.intersects((enemy1->rect)) && tank.type == 0){
        //子弹消失并初始化
        tank.bullet.isMove = false;
        tank.bullet.rect.setRect(tank.rect.x()+15, tank.rect.y()+15, 10, 10);
        tank.bulletNum = true;
        //敌人消失(unfinished)
        delete enemy1;
        if(enemy1)
            enemy1 = new Tank(1);
        enemy1->dir = ddown;
        enemy1->rect.setRect(40, 40, 40, 40);
        enemy1->x = 40;
        enemy1->y = 40;

        QSound::play(":/music/res/sound/player_bomb.wav");

        enemyDestroyed ++;

        return true;
    }
    if(tank.bullet.rect.intersects((enemy2->rect)) && tank.type == 0){
        //子弹消失并初始化
        tank.bullet.isMove = false;
        tank.bullet.rect.setRect(tank.rect.x()+15, tank.rect.y()+15, 10, 10);
        tank.bulletNum = true;
        //敌人消失(unfinished)
        if(enemy2)
        delete enemy2;
        enemy2 = new Tank(1);
        enemy2->dir = ddown;
        enemy2->rect.setRect(120, 40, 40, 40);
        enemy2->x = 120;
        enemy2->y = 40;

        QSound::play(":/music/res/sound/player_bomb.wav");

        enemyDestroyed ++;

        return true;
    }
//    if(tank.bullet.rect.intersects((enemy3->rect)) && tank.type == 0){
//        //子弹消失并初始化
//        tank.bullet.isMove = false;
//        tank.bullet.rect.setRect(tank.rect.x()+15, tank.rect.y()+15, 10, 10);
//        tank.bulletNum = true;
//        //敌人消失(unfinished)
//        if(enemy3)
//        delete enemy3;
//        enemy3 = new Tank(1);
//        enemy3->dir = ddown;
//        enemy3->rect.setRect(240, 40, 40, 40);
//        enemy3->x = 240;
//        enemy3->y = 40;

//        QSound::play(":/music/res/sound/player_bomb.wav");

//        enemyDestroyed ++;

//        return true;
//    }


//    if(tank.bullet.rect.intersects((enemy4->rect))){
//        //子弹消失并初始化
//        tank.bullet.isMove = false;
//        tank.bullet.rect.setRect(tank.rect.x()+15, tank.rect.y()+15, 10, 10);
//        tank.bulletNum = true;
//        //敌人消失(unfinished)
//        if(enemy4)
//        delete enemy4;
//        enemy4 = new Tank(1);
//        enemy4->dir = ddown;
//        enemy4->rect.setRect(0, 0, 40, 40);

//        enemyDestroyed ++;

//        return true;
//    }
//    if(tank.bullet.rect.intersects((enemy5->rect))){
//        //子弹消失并初始化
//        tank.bullet.isMove = false;
//        tank.bullet.rect.setRect(tank.rect.x()+15, tank.rect.y()+15, 10, 10);
//        tank.bulletNum = true;
//        //敌人消失(unfinished)
//        if(enemy5)
//        delete enemy5;
//        enemy5 = new Tank(1);
//        enemy5->dir = ddown;
//        enemy5->rect.setRect(0, 0, 40, 40);

//        enemyDestroyed ++;

//        return true;
//    }

    return false;
}

void BattlePage::paintEvent(QPaintEvent *event)
{
    QPainter p(this);
    //画背景图
    p.drawPixmap(0, 0, width(), height(), QPixmap("../Image/black.png"));

    //画子弹
    if(player->bullet.isMove == true){
        if(player->bullet.dir == dup)
            p.drawPixmap(player->bullet.rect, player->bullet.upImage);
        else if(player->bullet.dir == ddown)
            p.drawPixmap(player->bullet.rect, player->bullet.downImage);
        else if(player->bullet.dir == dleft)
            p.drawPixmap(player->bullet.rect, player->bullet.leftImage);
        else if(player->bullet.dir == dright)
            p.drawPixmap(player->bullet.rect, player->bullet.rightImage);
    }
    if(enemy1->bullet.isMove == true){
        if(enemy1->bullet.dir == dup)
            p.drawPixmap(enemy1->bullet.rect, enemy1->bullet.upImage);
        else if(enemy1->bullet.dir == ddown)
            p.drawPixmap(enemy1->bullet.rect, enemy1->bullet.downImage);
        else if(enemy1->bullet.dir == dleft)
            p.drawPixmap(enemy1->bullet.rect, enemy1->bullet.leftImage);
        else if(enemy1->bullet.dir == dright)
            p.drawPixmap(enemy1->bullet.rect, enemy1->bullet.rightImage);
    }
    if(enemy2->bullet.isMove == true){
        if(enemy2->bullet.dir == dup)
            p.drawPixmap(enemy2->bullet.rect, enemy2->bullet.upImage);
        else if(enemy2->bullet.dir == ddown)
            p.drawPixmap(enemy2->bullet.rect, enemy2->bullet.downImage);
        else if(enemy2->bullet.dir == dleft)
            p.drawPixmap(enemy2->bullet.rect, enemy2->bullet.leftImage);
        else if(enemy2->bullet.dir == dright)
            p.drawPixmap(enemy2->bullet.rect, enemy2->bullet.rightImage);
    }
    if(enemy3->bullet.isMove == true){
        if(enemy3->bullet.dir == dup)
            p.drawPixmap(enemy3->bullet.rect, enemy3->bullet.upImage);
        else if(enemy3->bullet.dir == ddown)
            p.drawPixmap(enemy3->bullet.rect, enemy3->bullet.downImage);
        else if(enemy3->bullet.dir == dleft)
            p.drawPixmap(enemy3->bullet.rect, enemy3->bullet.leftImage);
        else if(enemy3->bullet.dir == dright)
            p.drawPixmap(enemy3->bullet.rect, enemy3->bullet.rightImage);
    }

    //画玩家
    if(player->dir == dup)
        p.drawPixmap(player->rect, player->upImage);
    else if(player->dir == ddown)
        p.drawPixmap(player->rect, player->downImage);
    else if(player->dir == dleft)
        p.drawPixmap(player->rect, player->leftImage);
    else if(player->dir == dright)
        p.drawPixmap(player->rect, player->rightImage);


    //for test
//    qDebug()<<player->rect.x();
//    qDebug()<<player->rect.y();

    //画敌人
    if(enemy1->dir == dup){
        p.drawPixmap(enemy1->rect, enemy1->upImage);
    }
    else if(enemy1->dir == ddown){
        p.drawPixmap(enemy1->rect, enemy1->downImage);
    }
    else if(enemy1->dir == dleft){
        p.drawPixmap(enemy1->rect, enemy1->leftImage);
    }
    else if(enemy1->dir == dright){
        p.drawPixmap(enemy1->rect, enemy1->rightImage);
    }

    if(enemy2->dir == dup){
        p.drawPixmap(enemy2->rect, enemy2->upImage);
    }
    else if(enemy2->dir == ddown){
        p.drawPixmap(enemy2->rect, enemy2->downImage);
    }
    else if(enemy2->dir == dleft){
        p.drawPixmap(enemy2->rect, enemy2->leftImage);
    }
    else if(enemy2->dir == dright){
        p.drawPixmap(enemy2->rect, enemy2->rightImage);
    }

    if(enemy3->dir == dup){
        p.drawPixmap(enemy3->rect, enemy3->upImage);
    }
    else if(enemy3->dir == ddown){
        p.drawPixmap(enemy3->rect, enemy3->downImage);
    }
    else if(enemy3->dir == dleft){
        p.drawPixmap(enemy3->rect, enemy3->leftImage);
    }
    else if(enemy3->dir == dright){
        p.drawPixmap(enemy3->rect, enemy3->rightImage);
    }

//    if(enemy4->dir == dup){
//        p.drawPixmap(enemy4->rect, enemy4->upImage);
//    }
//    else if(enemy4->dir == ddown){
//        p.drawPixmap(enemy4->rect, enemy4->downImage);
//    }
//    else if(enemy4->dir == dleft){
//        p.drawPixmap(enemy4->rect, enemy4->leftImage);
//    }
//    else if(enemy4->dir == dright){
//        p.drawPixmap(enemy4->rect, enemy4->rightImage);
//    }

//    if(enemy5->dir == dup){
//        p.drawPixmap(enemy5->rect, enemy5->upImage);
//    }
//    else if(enemy5->dir == ddown){
//        p.drawPixmap(enemy5->rect, enemy5->downImage);
//    }
//    else if(enemy5->dir == dleft){
//        p.drawPixmap(enemy5->rect, enemy5->leftImage);
//    }
//    else if(enemy5->dir == dright){
//        p.drawPixmap(enemy5->rect, enemy5->rightImage);
//    }

//    p.drawPixmap(enemy2->rect, enemy2->downImage);
//    p.drawPixmap(enemy3->rect, enemy3->downImage);
//    p.drawPixmap(enemy4->rect, enemy4->downImage);
//    p.drawPixmap(enemy5->rect, enemy5->downImage);

    for(int x=0;x<Boarder;x++){
        for(int y=0;y<Boarder;y++){
            if(battle.battleField[x][y] == 1){
                p.drawPixmap(x*20, y*20, BasicSize, BasicSize, battle.wall);
            }
            else if(battle.battleField[x][y] == 2){
                p.drawPixmap(x*20, y*20, BasicSize, BasicSize, battle.stone);
            }
            else if(battle.battleField[x][y] == 3){
                p.drawPixmap(x*20, y*20, BaseSize, BaseSize, battle.base);
            }
            else
                continue;
        }
    }
}

void BattlePage::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape){
        emit escape();
    }
    else if(event->key() == Qt::Key_Up){
        player->isMove = true;
        player->dir = dup;
    }
    else if(event->key() == Qt::Key_Down){
        player->isMove = true;
        player->dir = ddown;
    }
    else if(event->key() == Qt::Key_Left){
        player->isMove = true;
        player->dir = dleft;
    }
    else if(event->key() == Qt::Key_Right){
        player->isMove = true;
        player->dir = dright;
    }
    else if(event->key() == Qt::Key_Space){
        player->shoot();
    }
    else{
        return;
    }
}

void BattlePage::keyReleaseEvent(QKeyEvent *event)
{
    if(event->key() != Qt::Key_Space){
        player->isMove = false;
    }
}

void BattlePage::tankMove(Tank *tank)
{   
    //游戏结束
    if(enemyDestroyed == 10){
        win.setText("游戏胜利！");
        win.show();
        this->timer->stop();
//        if(timer != nullptr)
//        delete timer;
//        if(player != nullptr)
//        delete player;
//        if(enemy1 != nullptr)
//        delete enemy1;
//        if(enemy2 != nullptr)
//        delete enemy2;
//        if(enemy3 != nullptr)
//        delete enemy3;
//        if(enemy4 != nullptr)
//        delete enemy4;
//        if(enemy5 != nullptr)
//        delete enemy5;
        //connect(&win, &QMessageBox::buttonClicked, this, &BattlePage::slot2);
        QSound::play(":/music/res/sound/win.wav");
        emit escape();
    }

    qDebug()<<isBoom(*player);
    isBoom(*enemy1);
    isBoom(*enemy2);
    isBoom(*enemy3);

    if(tank->type == 1){
        tank->shoot();
        tank->isMove = 1;
        enemyMove();
//        static int d;
//        srand((unsigned)time(NULL));
//        d = rand()%5;
//        if(d==0){
//            tank->dir = dup;
//            //tank->upImage.load(":/enemy/res/pic/gray-tank/1-2-1.gif");
//        }
//        else if(d == 1 || d == 4){
//            tank->dir = ddown;
//            //tank->upImage.load(":/enemy/res/pic/gray-tank/1-4-1.gif");
//        }
//        else if(d == 2){
//            tank->dir = dleft;
//            //tank->upImage.load(":/enemy/res/pic/gray-tank/1-1-1.gif");
//        }
//        else if(d == 3){
//            tank->dir = dright;
//            //tank->upImage.load(":/enemy/res/pic/gray-tank/1-3-1.gif");
//        }
    }


    //子弹移动
    if(tank->bullet.isMove == true){
        if(tank->bullet.dir == dup){
            tank->bullet.y -= tank->bullet.speed;
            tank->bullet.rect.moveTo(tank->bullet.x, tank->bullet.y);
        }
        else if(tank->bullet.dir == ddown){
            tank->bullet.y += tank->bullet.speed;
            tank->bullet.rect.moveTo(tank->bullet.x, tank->bullet.y);
        }
        else if(tank->bullet.dir == dleft){
            tank->bullet.x -= tank->bullet.speed;
            tank->bullet.rect.moveTo(tank->bullet.x, tank->bullet.y);
        }
        else if(tank->bullet.dir == dright){
            tank->bullet.x += tank->bullet.speed;
            tank->bullet.rect.moveTo(tank->bullet.x, tank->bullet.y);
        }
    }

    //判断子弹出界
    if(tank->bullet.rect.x()<0 || tank->bullet.rect.x()>580 || tank->bullet.rect.y()<0 || tank->bullet.rect.y()>560){
        tank->bullet.isMove = false;
        tank->bullet.rect.setRect(tank->rect.x()+15, tank->rect.y()+15, 10, 10);
        tank->bulletNum = true;
    }


    //坦克移动
    int cx = tank->rect.x()/BasicSize;
    int cy = tank->rect.y()/BasicSize;

    // || tank->rect.y()<5 || tank->rect.x()>575 || tank->rect.y()>555)
    //将要出界时停止
    if(tank->rect.x()<0){
        tank->isMove = false;
        tank->x = 0;
        tank->rect.moveTo(0, tank->y);
        return;
    }
    else if(tank->rect.x()>580){
        tank->isMove = false;
        tank->x = 580;
        tank->rect.moveTo(580, tank->y);
        return;
    }
    else if(tank->rect.y()<0){
        tank->isMove = false;
        tank->y = 0;
        tank->rect.moveTo(tank->x, 0);
        return;
    }
    else if(tank->rect.y()>560){
        tank->isMove = false;
        tank->y = 560;
        tank->rect.moveTo(tank->x, 560);
        return;
    }

    if(tank->dir == dup && tank->isMove){
        //遇到障碍物时停止
        if(tank->rect.intersects(battle.rect[cx][cy])
                || tank->rect.intersects(battle.rect[cx+1][cy])
                || tank->rect.intersects(battle.rect[cx+2][cy]))
        {
            qDebug()<<"collide";
            return;
        }
        //否则移动
        tank->dir = dup;
        tank->y -= tank->speed;
        tank->rect.moveTo(tank->x, tank->y);
    }

    else if(tank->dir == ddown && tank->isMove){

        //遇到障碍物时停止
        if(tank->rect.intersects(battle.rect[cx][cy+2])
            || tank->rect.intersects(battle.rect[cx-1][cy+2])
            || tank->rect.intersects(battle.rect[cx-2][cy+2]))
        {
            qDebug()<<"collide";
            return;
        }
        //否则移动
        tank->dir = ddown;
        tank->y += tank->speed;
        tank->rect.moveTo(tank->x, tank->y);
    }

    else if(tank->dir == dright && tank->isMove){

        //遇到障碍物时停止
        if(tank->rect.intersects(battle.rect[cx+2][cy])
            || tank->rect.intersects(battle.rect[cx+2][cy+1])
            || tank->rect.intersects(battle.rect[cx+2][cy+2]))
        {
            qDebug()<<"collide";
            return;
        }
        //否则移动
        tank->dir = dright;
        tank->x += tank->speed;
        tank->rect.moveTo(tank->x, tank->y);
    }

    else if(tank->dir == dleft && tank->isMove){

        //遇到障碍物时停止
        //qDebug()<<cx<<" "<<cy;
        //qDebug()<<tank->rect;
        //qDebug()<<battle.rect[cx][cy]<<" "<<battle.rect[cx][cy+1]<<" "<<battle.rect[cx][cy+2];
        if(tank->rect.intersects(battle.rect[cx][cy])
            || tank->rect.intersects(battle.rect[cx][cy+1])
            || tank->rect.intersects(battle.rect[cx][cy+2]))
        {
            qDebug()<<"collide";
            return;
        }
        //否则移动
        tank->dir = dleft;
        tank->x -= tank->speed;
        tank->rect.moveTo(tank->x, tank->y);
    }

    update();
}

void BattlePage::enemyMove()
{
    //敌方坦克移动
    enemy1->isMove = true;
    enemy2->isMove = true;
    enemy3->isMove = true;
//    enemy4->isMove = true;
//    enemy5->isMove = true;
    static int d;
    srand((unsigned)time(NULL));
    //随机方向移动
    d = rand()%9;
    if(d==0)
    {
        enemy1->dir = dup;
        enemy2->dir = dleft;
    }
    else if(d == 1)
    {
        enemy1->dir = ddown;
        enemy2->dir = dup;
    }
    else if(d == 2)
    {
        enemy1->dir = dleft;
        enemy2->dir = ddown;
    }
    else if(d == 3)
    {
        enemy1->dir = dright;
        enemy2->dir = dright;
    }
    else if(d == 5)
    {
        enemy3->dir = dup;
//        enemy4->dir = ddown;
    }
    else if(d == 6)
    {
        enemy3->dir = ddown;
//        enemy4->dir = dright;
    }
    else if(d == 7)
    {
        enemy3->dir = dleft;
//        enemy4->dir = dup;
    }
    else if(d == 8)
    {
        enemy3->dir = dright;
//        enemy4->dir = dleft;
    }
//    else if(d == 9)
//    {
//        enemy5->dir = dup;
//    }
//    else if(d == 10)
//    {
//        enemy5->dir = ddown;
//    }
//    else if(d == 11)
//    {
//        enemy5->dir = dleft;
//    }
//    else if(d == 12)
//    {
//        enemy5->dir = dright;
//    }
}
