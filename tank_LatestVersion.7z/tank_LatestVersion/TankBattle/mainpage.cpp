#include "mainpage.h"
#include "ui_mainpage.h"
#include <QPainter>
#include <QPixmap>
#include <QSound>

MainPage::MainPage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainPage)
{
    ui->setupUi(this);
    battlePage = new BattlePage;
    this->move(300, 100);
    this->setWindowTitle("坦克大战");
    ui->buttonStart->setFont(QFont("微软雅黑", 20, 700));
    ui->buttonStart->setStyleSheet("color:red");
    ui->buttonExit->setFont(QFont("微软雅黑", 20, 700));
    ui->buttonExit->setStyleSheet("color:red");
    ui->buttonStart->setFlat(true);
    ui->buttonExit->setFlat(true);

    connect(ui->buttonStart, &QPushButton::clicked, this, &MainPage::slot);
    connect(ui->buttonExit, &QPushButton::clicked, this, &MainPage::slot3);
    connect(battlePage, &BattlePage::escape, this, &MainPage::slot2);

}

MainPage::~MainPage()
{
    delete ui;
}

void MainPage::paintEvent(QPaintEvent *event)
{
    QPainter p(this);
    p.drawPixmap(0, 0, width(), height(), QPixmap("../Image/mainpage.png"));
}

void MainPage::keyPressEvent(QKeyEvent *event)
{
    //按E进入游戏
    if(event->key() == Qt::Key_E || event->key() == Qt::Key_Enter){
        this->close();
        battlePage->show();
        QSound::play(":/music/res/sound/bgm.wav");
    }
    //esc退出游戏
    else if(event->key() == Qt::Key_Escape)
        slot3();
    else
        return;
}

//开始游戏
void MainPage::slot()
{
    this->close();
    battlePage->show();
    QSound::play(":/music/res/sound/bgm.wav");
}

void MainPage::slot2()
{
    this->show();
    //battlePage->close();
    delete battlePage;
    battlePage = new BattlePage;
}

//退出游戏
void MainPage::slot3()
{
    delete battlePage;
    this->close();
}
